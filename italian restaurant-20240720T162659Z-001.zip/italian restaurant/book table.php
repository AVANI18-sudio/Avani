<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php
		$host='localhost';
        $user='root';
        $pass='';
        $dbname='food';

        $conn=new mysqli($host,$user,$pass,$dbname);
        if ($conn->connect_error) {
        	printf("connect failed:%s<br/>",$mysqli->connect_error);
			exit();
        }
        printf("connected successfully.<br/>");
       	$name = $_POST['name'];
        $email = $_POST['email'];
        $phone= $_POST['phone'];
        $date= $_POST['date'];
        $time= $_POST['time'];
        $people= $_POST['people'];
        $message = $_POST['message'];

        $sql="INSERT INTO booktable(name,email,phone,date,time,people,message) values ('{$name}','{$email}','{$phone}','{$date}','{$time}','{$people}','{$message}')";
        if ($conn->query($sql)===TRUE)
         {
             echo "new record created successfully.";
             header("location:index.html");
         } 
         else
         {
            echo "error:".$sql."<br>".$conn->error;
        }
        mysqli_free_result($result);
        $mysqli->close();
    ?>

</body>
</html>