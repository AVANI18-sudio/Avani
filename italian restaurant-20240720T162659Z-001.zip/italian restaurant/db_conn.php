<?php
		$host='localhost';
        $user='root';
        $pass='';
        $dbname='food';
        $conn=new mysqli($host,$user,$pass,$dbname);
        if ($conn->connect_error) {
        	printf("connect failed:%s<br/>",$mysqli->connect_error);
			exit();
        }
        printf("connected successfully.<br/>");
       	$username = $_POST['username'];
        $password = $_POST['password'];
 
        $sql="INSERT INTO login(username,password) values ('{$username}','{$password}')";
        if ($conn->query($sql)===TRUE)
         {
             echo "new record created successfully.";
             header("location:index.html");
         } 
         else
         {
            echo "error:".$sql."<br>".$conn->error;
        }
        mysqli_free_result($result);
        $mysqli->close();
    ?>
?>
