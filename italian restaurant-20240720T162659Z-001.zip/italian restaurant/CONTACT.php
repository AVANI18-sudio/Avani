<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php
		$host='localhost';
        $user='root';
        $pass='';
        $dbname='food';

        $conn=new mysqli($host,$user,$pass,$dbname);
        if ($conn->connect_error) {
        	printf("connect failed:%s<br/>",$mysqli->connect_error);
			exit();
        }
        printf("connected successfully.<br/>");
       	$name = $_POST['name'];
        $Email = $_POST['Email'];
        $Subject = $_POST['subject'];
        $address = $_POST['address'];


        $sql="INSERT INTO contact(name,Email,Subject,address) values ('{$name}','{$Email}','{$Subject}','{$address}')";
        if ($conn->query($sql)===TRUE) {
        	 echo "new record created successfully.";
        	 header("location:index.html");
    } else {
        echo "error:".$sql."<br>".$conn->error;
    }
        mysqli_free_result($result);
        $mysqli->close();
?>
     
   
</body>
</html>