<style type="text/css">
    body{
      background-image: url("b1.avif");
        background-color: ;
    }
    #frm{
        border: solid gray 1px;
        width: 25%;
        border-radius: 2px;
        margin: 200px auto;
        background: white;
        padding: 50px;
    }
    #btn{
        color: #fdfdfd;
        background: #337ab7;
        padding: 7px;
        margin-left: 70%;
    }
</style>

            <!--login start-->

    <!DOCTYPE html>
    <html>
    <head>
        <title>LOGIN FORM</title>
    </head>
    <body>
            <div id="frm">
                <center><h1>LOGIN</h1></center>
                <form name="f1" action="login2.php" onsubmit="return validation()" method="POST">
                    <p>
                        <label>Username:</label>
                        <input type="text" id="username" name="username" placeholder="enter username" required />
                    </p>
                    <p>
                        <label>Password:</label>
                        <input type="text" id="password" name="password" placeholder="enter password" required />
                    </p>
                    <p>
                        <input type="submit" id="btn" value="login"/>
                    </p>
                    
                    
                </form>
            </div>



    <script>
        function validation() 
        {
            var id=document.f1.user.value;
            var ps=document.f1.pass.value;
            if (id.length=="" && ps.length=="") 
            {
                alert("username and password fields are empty");
                return false;
            }
            else
            {
                if (id.length=="") 
                {
                    alert("password field is empty");
                    return false;
                }
            }
        }
    </script>
    </body>
    </html>