<?php
  if (isset($_POST['submit'])) {
        $name = $_POST['name'];
        $Email = $_POST['Email'];
        $Subject = $_POST['Subject'];
        $Message = $_POST['Message'];
        
        $host='localhost';
        $user='root';
        $pass='';
        $dbname='food';
        echo $first_name;
echo $last_name;
exit();


        $conn=mysqli_connect($host,$user,$pass,$dbname);
        if(conn)
        {
          echo "okk";

        }
        else
        {
          echo "noyt okk";
        }

        $sql="INSERT INTO contact(name,Email,Subject,Message) values ('$name','$Email','$Subject','$Message')";
         mysqli_query($conn,$sql);
   } 
 ?>
