<!DOCTYPE html>
<html>
<head>
    <title> order</title>
</head>
<body>
<?php
        $host='localhost';
        $user='root';
        $pass='';
        $dbname='food';
    // Create a connection
    $conn = mysqli_connect($host, $user, $pass, $dbname);
    // Check the connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
     echo "Connected successfully";
        $name = $_POST['name'];
        $email = $_POST['email'];
        $phone= $_POST['phone'];
        $item= $_POST['item'];
        $whichitem= $_POST['whichitem'];
        $quantity= $_POST['quantity'];
        $address = $_POST['address'];

        $sql="INSERT INTO orders (name,email,phone,item,whichitem,quantity,address) values ('{$name}','{$email}','{$phone}','{$item}','{$whichitem}','{$quantity}','{$address}')";



    if ($conn->query($sql)===TRUE) {
             echo "new record created successfully.";
             header("location:ordersuc.php");
         }
    else 
    {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    mysqli_close($conn);
?>
</body>
</html>